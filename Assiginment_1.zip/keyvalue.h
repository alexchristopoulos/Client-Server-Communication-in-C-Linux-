#ifndef _KEYVALUE_H
#define _KEYVALUE_H
char *get(char *key);
void put(char *key,char *value);
#endif
